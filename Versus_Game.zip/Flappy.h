#ifndef FLAPPY_H
#define FLAPPY_H

#include <Arduino.h>
#include <U8g2lib.h>

// External declaration of the OLED screen
extern U8G2_SH1107_SEEED_128X128_1_HW_I2C u8g2;

class Flappy {
public:
    Flappy();
    void setup();
    void loop();
    bool isGameOver();
    int getScore();
    void setBestScore(int score);
    int getBestScore();

private:
    void update();
    void draw();

    int x, y;
    int score;
    int bestScore;
    int pipeX;
    int pipeGapY;
    unsigned long lastUpdate;
    unsigned long startTime;
    bool gameOver;

    const int PIPE_WIDTH = 18;
    const int GAP_HEIGHT = 45;
    const unsigned long UPDATE_INTERVAL = 15;
};

#endif // FLAPPY_H

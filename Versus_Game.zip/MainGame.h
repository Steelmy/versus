#ifndef MAINGAME_H
#define MAINGAME_H

#include <Arduino.h>
#include <Grove_LED_Bar.h>

// External variables and functions
extern Grove_LED_Bar ledBar;
extern const int RED_BUTTON_PINS[6];
extern const int RED_LED_PINS[6];
extern const int BLUE_BUTTON_PINS[6];
extern const int BLUE_LED_PINS[6];
extern const unsigned long GAME_DURATION;

extern void playSuccessSound();
extern void playErrorSound();
extern bool readButtonFast(int buttonIndex, int pin);


class MainGame {
public:
    MainGame();
    void setup(int initialDifficulty);
    void loop();
    bool isGameOver();
    int getRedScore();
    int getBlueScore();
    void reset();
    void setDifficulty(int newDifficulty);
    void displayScore();
    void updateLedBarTimer();


private:
    void checkButtonPresses();
    void checkLedTimeout();
    void activateRandomLed(bool isRed);

    int redScore;
    int blueScore;
    int difficulty;
    int ledOnTime;
    unsigned long gameStartTime;
    unsigned long simpleGameTimer;
    bool gameTimerActive;
    int activeRedLed;
    int activeBlueLed;
    unsigned long redLedStartTime;
    unsigned long blueLedStartTime;
    int lastRedLeds[2];
    int lastBlueLeds[2];

    unsigned long lastLedBarUpdate;
    int currentBarSegment;
    bool barBlinkState;
};

#endif // MAINGAME_H
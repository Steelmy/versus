#ifndef PONG_MASTER_H
#define PONG_MASTER_H

#include <Arduino.h>
#include <U8g2lib.h>

// External declaration of the OLED screen and pins
extern U8G2_SH1107_SEEED_128X128_1_HW_I2C u8g2;
extern const int POT_PIN_1;
extern const int POT_PIN_2;
extern const int BLUE_BUTTON_PINS[6];
extern const int RED_BUTTON_PINS[6];


// Enum for the new power-ups
enum PowerUpType {
  NONE,
  BLINK_OPPONENT,
  INVERT_OPPONENT_CONTROLS,
  STRONG_HIT,
  SLOW_RETURNED_BALL
};

class PongMaster {
public:
  PongMaster();
  void setup();
  void loop();
  bool isGameOver();
  int getScore1();
  int getScore2();

private:
  void draw();
  void handleInput();
  void updateBall();
  void updatePaddles();
  void updatePowerUps();
  void resetBall(bool toLeft);

  // Game variables
  float paddle1Y, paddle2Y;
  float ballX, ballY;
  float ballVX, ballVY;
  int score1, score2;

  // Game constants
  const int PADDLE_WIDTH = 4;
  const int PADDLE_HEIGHT = 20;
  const int BALL_SIZE = 4;

  // Power-up variables
  PowerUpType powerUp1, powerUp2;
  unsigned long lastPowerUpSpawnTime;
  const unsigned long POWERUP_COOLDOWN = 10000;

  // Power-up effect states
  bool p1_controls_inverted, p2_controls_inverted;
  unsigned long p1_invert_endTime, p2_invert_endTime;

  unsigned long p1_opponent_blink_endTime, p2_opponent_blink_endTime;

  bool p1_strong_hit_armed, p2_strong_hit_armed;

  bool p1_slow_ball_armed, p2_slow_ball_armed;
  unsigned long ball_slow_endTime;

  // Game timer
  unsigned long gameStartTime;
  const unsigned long GAME_DURATION_MS = 60000;

  // Last chance mechanic
  bool lastChanceActive;
  bool lastChanceFinished;
  bool lastChanceTowardsLeft;
};

#endif // PONG_MASTER_H
#ifndef DISPLAY_MANAGER_H
#define DISPLAY_MANAGER_H

#include <U8g2lib.h>

class DisplayManager {
public:
    // Initialisation de l'écran
    static void init(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display);
    
    // Fonctions d'affichage
    static void showMenu(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display);
    static void showDifficultySelect(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display, int difficulty);
    static void showCountdown(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display, int countdownValue);
    static void showGameScore(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display, int redScore, int blueScore, unsigned long remainingTime);
    static void showGameOver(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display, int redScore, int blueScore);
    
    // Fonction utilitaire pour afficher un message simple
    static void showMessage(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display, const char* line1, const char* line2 = "");
    
    // Ajout de la fonction pour inverser les couleurs
    static void toggleWhiteMode(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display);

private:
    static bool whiteMode;
};

#endif

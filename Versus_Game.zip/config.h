#ifndef CONFIG_H
#define CONFIG_H

// ===== CONFIGURATION DES PINS =====

// LED Buttons Rouges (Joueur 1)
extern const int RED_BUTTON_PINS[6];
extern const int RED_LED_PINS[6];

// LED Buttons Bleus (Joueur 2)
extern const int BLUE_BUTTON_PINS[6];
extern const int BLUE_LED_PINS[6];

// LED Bar (10 segments)
extern const int LED_BAR_CLOCK;
extern const int LED_BAR_DATA;

// Potentiomètre
extern const int POT_PIN;

// Buzzer
extern const int BUZZER_PIN;

// Dual Button (navigation menu)
extern const int DUAL_BUTTON_1;
extern const int DUAL_BUTTON_2;

// Pins pour Pong (si différents)
extern const int POT_PIN_1;
extern const int POT_PIN_2;

#endif // CONFIG_H

#include "PongMaster.h"
#include "config.h"

// External pin definitions from Jeux.ino
extern const int BLUE_LED_PINS[6];
extern const int RED_LED_PINS[6];

PongMaster::PongMaster() {
    // Initialize variables in setup() to ensure they are reset for each game
}

void PongMaster::setup() {
    paddle1Y = 64 - (PADDLE_HEIGHT / 2);
    paddle2Y = 64 - (PADDLE_HEIGHT / 2);
    score1 = 0;
    score2 = 0;
    resetBall(true);

    powerUp1 = NONE;
    powerUp2 = NONE;
    lastPowerUpSpawnTime = millis();
    gameStartTime = millis();

    p1_controls_inverted = false;
    p2_controls_inverted = false;
    p1_invert_endTime = 0;
    p2_invert_endTime = 0;
    p1_opponent_blink_endTime = 0;
    p2_opponent_blink_endTime = 0;
    p1_strong_hit_armed = false;
    p2_strong_hit_armed = false;
    p1_slow_ball_armed = false;
    p2_slow_ball_armed = false;
    ball_slow_endTime = 0;

    lastChanceActive = false;
    lastChanceFinished = false;

    // Turn on movement LEDs
    digitalWrite(BLUE_LED_PINS[0], HIGH);
    digitalWrite(BLUE_LED_PINS[1], HIGH);
    digitalWrite(RED_LED_PINS[0], HIGH);
    digitalWrite(RED_LED_PINS[1], HIGH);
}

void PongMaster::loop() {
    if (isGameOver()) {
        draw();
    } else {
        handleInput();
        updatePaddles();
        updatePowerUps();
        updateBall();
        draw();
    }
}

bool PongMaster::isGameOver() {
    if (!lastChanceActive && (score1 >= 5 || score2 >= 5)) {
        return true;
    }

    if (!lastChanceActive && (millis() - gameStartTime >= GAME_DURATION_MS)) {
        lastChanceActive = true;
        lastChanceFinished = false;
        lastChanceTowardsLeft = (ballVX < 0);
    }

    return lastChanceFinished;
}

void PongMaster::draw() {
    unsigned long currentTime = millis();
    u8g2.firstPage();
    do {
        // Draw paddles with blink effect
        if (currentTime >= p1_opponent_blink_endTime || (currentTime < p1_opponent_blink_endTime && (currentTime / 300) % 2 == 0)) {
            u8g2.drawBox(5, paddle1Y, PADDLE_WIDTH, PADDLE_HEIGHT);
        }
        if (currentTime >= p2_opponent_blink_endTime || (currentTime < p2_opponent_blink_endTime && (currentTime / 300) % 2 == 0)) {
            u8g2.drawBox(128 - 5 - PADDLE_WIDTH, paddle2Y, PADDLE_WIDTH, PADDLE_HEIGHT);
        }

        u8g2.drawBox(ballX - BALL_SIZE / 2, ballY - BALL_SIZE / 2, BALL_SIZE, BALL_SIZE);
        for (int i = 0; i < 128; i += 10) {
            u8g2.drawVLine(64, i, 5);
        }

        u8g2.setFont(u8g2_font_ncenB10_tr);
        char scoreStr[5];
        sprintf(scoreStr, "%d", score1);
        u8g2.drawStr(40, 15, scoreStr);
        sprintf(scoreStr, "%d", score2);
        u8g2.drawStr(128 - 40 - u8g2.getStrWidth(scoreStr), 15, scoreStr);

        u8g2.setFont(u8g2_font_5x7_tr);
        // ... (Power-up name display can be added here if desired)

    } while (u8g2.nextPage());
}

void PongMaster::handleInput() {
    unsigned long currentTime = millis();
    if (digitalRead(BLUE_BUTTON_PINS[2]) == LOW && powerUp1 != NONE) {
        switch (powerUp1) {
            case BLINK_OPPONENT: p2_opponent_blink_endTime = currentTime + 1200; break;
            case INVERT_OPPONENT_CONTROLS: p2_controls_inverted = true; p2_invert_endTime = currentTime + 5000; break;
            case STRONG_HIT: p1_strong_hit_armed = true; break;
            case SLOW_RETURNED_BALL: p1_slow_ball_armed = true; break;
            default: break;
        }
        powerUp1 = NONE;
    }

    if (digitalRead(RED_BUTTON_PINS[2]) == LOW && powerUp2 != NONE) {
        switch (powerUp2) {
            case BLINK_OPPONENT: p1_opponent_blink_endTime = currentTime + 1200; break;
            case INVERT_OPPONENT_CONTROLS: p1_controls_inverted = true; p1_invert_endTime = currentTime + 5000; break;
            case STRONG_HIT: p2_strong_hit_armed = true; break;
            case SLOW_RETURNED_BALL: p2_slow_ball_armed = true; break;
            default: break;
        }
        powerUp2 = NONE;
    }
}

void PongMaster::updatePaddles() {
    const float PADDLE_SPEED = 8.0f;
    float step = PADDLE_SPEED;

    // Player 1 (Blue)
    if (p1_controls_inverted ? (digitalRead(BLUE_BUTTON_PINS[1]) == LOW) : (digitalRead(BLUE_BUTTON_PINS[0]) == LOW)) paddle1Y -= step;
    if (p1_controls_inverted ? (digitalRead(BLUE_BUTTON_PINS[0]) == LOW) : (digitalRead(BLUE_BUTTON_PINS[1]) == LOW)) paddle1Y += step;

    // Player 2 (Red)
    if (p2_controls_inverted ? (digitalRead(RED_BUTTON_PINS[0]) == LOW) : (digitalRead(RED_BUTTON_PINS[1]) == LOW)) paddle2Y -= step;
    if (p2_controls_inverted ? (digitalRead(RED_BUTTON_PINS[1]) == LOW) : (digitalRead(RED_BUTTON_PINS[0]) == LOW)) paddle2Y += step;
    
    // Constrain paddles to screen
    if (paddle1Y < 0) paddle1Y = 0;
    if (paddle1Y > 128 - PADDLE_HEIGHT) paddle1Y = 128 - PADDLE_HEIGHT;
    if (paddle2Y < 0) paddle2Y = 0;
    if (paddle2Y > 128 - PADDLE_HEIGHT) paddle2Y = 128 - PADDLE_HEIGHT;
}

void PongMaster::updateBall() {
    unsigned long currentTime = millis();
    float speedFactor = 1.0f;
    if (millis() - gameStartTime >= 45000) {
        speedFactor = 2.0f;
    }
    if (lastChanceActive) {
        speedFactor = 2.0f;
    }
    float slowFactor = (currentTime < ball_slow_endTime) ? 0.5f : 1.0f;

    ballX += ballVX * speedFactor * slowFactor;
    ballY += ballVY * speedFactor * slowFactor;

    if (ballY - BALL_SIZE / 2 < 0 || ballY + BALL_SIZE / 2 > 128) ballVY = -ballVY;

    // Collision with Player 1 (Left)
    if (ballVX < 0 && ballX - BALL_SIZE / 2 < 5 + PADDLE_WIDTH && ballX > 5 && ballY > paddle1Y && ballY < paddle1Y + PADDLE_HEIGHT) {
        ballVX = -ballVX;
        if (p1_strong_hit_armed) {
            ballVX *= 2;
            p1_strong_hit_armed = false;
        }
        if (p2_slow_ball_armed) {
            ball_slow_endTime = currentTime + 1500;
            p2_slow_ball_armed = false;
        }
        ballX = 5 + PADDLE_WIDTH + BALL_SIZE / 2;
        if (lastChanceActive && lastChanceTowardsLeft) lastChanceFinished = true;
    }

    // Collision with Player 2 (Right)
    if (ballVX > 0 && ballX + BALL_SIZE / 2 > 128 - 5 - PADDLE_WIDTH && ballX < 128 - 5 && ballY > paddle2Y && ballY < paddle2Y + PADDLE_HEIGHT) {
        ballVX = -ballVX;
        if (p2_strong_hit_armed) {
            ballVX *= 2;
            p2_strong_hit_armed = false;
        }
        if (p1_slow_ball_armed) {
            ball_slow_endTime = currentTime + 1500;
            p1_slow_ball_armed = false;
        }
        ballX = 128 - 5 - PADDLE_WIDTH - BALL_SIZE / 2;
        if (lastChanceActive && !lastChanceTowardsLeft) lastChanceFinished = true;
    }

    // Score
    if (ballX < 0) {
        score2++;
        if (lastChanceActive && lastChanceTowardsLeft) lastChanceFinished = true; else resetBall(false);
    }
    if (ballX > 128) {
        score1++;
        if (lastChanceActive && !lastChanceTowardsLeft) lastChanceFinished = true; else resetBall(true);
    }
}

void PongMaster::updatePowerUps() {
    unsigned long currentTime = millis();
    if (p1_controls_inverted && currentTime > p1_invert_endTime) p1_controls_inverted = false;
    if (p2_controls_inverted && currentTime > p2_invert_endTime) p2_controls_inverted = false;

    if (currentTime - lastPowerUpSpawnTime > POWERUP_COOLDOWN) {
        if (powerUp1 == NONE) powerUp1 = (PowerUpType)random(1, 5);
        if (powerUp2 == NONE) powerUp2 = (PowerUpType)random(1, 5);
        lastPowerUpSpawnTime = currentTime;
    }
    
    digitalWrite(BLUE_LED_PINS[2], (powerUp1 != NONE) ? ((currentTime / 200) % 2) : LOW);
    digitalWrite(RED_LED_PINS[2], (powerUp2 != NONE) ? ((currentTime / 200) % 2) : LOW);
}

void PongMaster::resetBall(bool toLeft) {
    ballX = 64;
    ballY = random(20, 108);
    ballVX = toLeft ? -2.5 : 2.5;
    ballVY = (random(0, 2) == 0 ? 1 : -1) * 1.5;
}

int PongMaster::getScore1() { return score1; }
int PongMaster::getScore2() { return score2; }
#include "MainGame.h"

MainGame::MainGame() {
    // Constructor
}

void MainGame::setup(int initialDifficulty) {
    reset();
    setDifficulty(initialDifficulty);
}

void MainGame::reset() {
    redScore = 0;
    blueScore = 0;
    activeRedLed = -1;
    activeBlueLed = -1;
    gameTimerActive = false;
    simpleGameTimer = 0;
    gameStartTime = 0;
    lastRedLeds[0] = -1;
    lastRedLeds[1] = -1;
    lastBlueLeds[0] = -1;
    lastBlueLeds[1] = -1;
    currentBarSegment = 10;

    for (int i = 0; i < 6; i++) {
        digitalWrite(RED_LED_PINS[i], LOW);
        digitalWrite(BLUE_LED_PINS[i], LOW);
    }
}

void MainGame::setDifficulty(int newDifficulty) {
    difficulty = newDifficulty;
    ledOnTime = 800 - (difficulty * 52);
}

void MainGame::loop() {
    if (!gameTimerActive) {
        gameStartTime = millis();
        simpleGameTimer = millis();
        gameTimerActive = true;
        activateRandomLed(true);
        activateRandomLed(false);
    }

    checkButtonPresses();
    checkLedTimeout();
    updateLedBarTimer();
    // displayScore(); // Should be called from the main loop
}

bool MainGame::isGameOver() {
    if (gameTimerActive && (millis() - simpleGameTimer >= GAME_DURATION)) {
        gameTimerActive = false;
        return true;
    }
    return false;
}

int MainGame::getRedScore() { return redScore; }
int MainGame::getBlueScore() { return blueScore; }

void MainGame::checkButtonPresses() {
    for (int i = 0; i < 6; i++) {
        if (readButtonFast(i, RED_BUTTON_PINS[i])) {
            if (i == activeRedLed) {
                digitalWrite(RED_LED_PINS[activeRedLed], LOW);
                redScore++;
                activeRedLed = -1; // Mark as hit
                // playSuccessSound();
            } else if (activeRedLed != -1) {
                if (redScore > 0) redScore--;
                                // playErrorSound();
            }
        }
    }
    for (int i = 0; i < 6; i++) {
        if (readButtonFast(i + 6, BLUE_BUTTON_PINS[i])) {
            if (i == activeBlueLed) {
                digitalWrite(BLUE_LED_PINS[activeBlueLed], LOW);
                blueScore++;
                activeBlueLed = -1; // Mark as hit
                // playSuccessSound();
            } else if (activeBlueLed != -1) {
                if (blueScore > 0) blueScore--;
                                // playErrorSound();
            }
        }
    }
}

void MainGame::checkLedTimeout() {
    if (millis() - redLedStartTime > ledOnTime) {
        if (activeRedLed != -1) { // Player missed
            digitalWrite(RED_LED_PINS[activeRedLed], LOW);
            // playErrorSound();
        }
        activateRandomLed(true);
    }
    if (millis() - blueLedStartTime > ledOnTime) {
        if (activeBlueLed != -1) { // Player missed
            digitalWrite(BLUE_LED_PINS[activeBlueLed], LOW);
            // playErrorSound();
        }
        activateRandomLed(false);
    }
}

void MainGame::activateRandomLed(bool isRed) {
    int randomLed;
    int attempts = 0;
    if (isRed) {
        do {
            randomLed = random(0, 6);
            attempts++;
        } while (attempts < 10 && (randomLed == lastRedLeds[0] || randomLed == lastRedLeds[1]));
        if (activeRedLed != -1) digitalWrite(RED_LED_PINS[activeRedLed], LOW);
        lastRedLeds[1] = lastRedLeds[0];
        lastRedLeds[0] = randomLed;
        activeRedLed = randomLed;
        digitalWrite(RED_LED_PINS[activeRedLed], HIGH);
        redLedStartTime = millis();
    } else {
        do {
            randomLed = random(0, 6);
            attempts++;
        } while (attempts < 10 && (randomLed == lastBlueLeds[0] || randomLed == lastBlueLeds[1]));
        if (activeBlueLed != -1) digitalWrite(BLUE_LED_PINS[activeBlueLed], LOW);
        lastBlueLeds[1] = lastBlueLeds[0];
        lastBlueLeds[0] = randomLed;
        activeBlueLed = randomLed;
        digitalWrite(BLUE_LED_PINS[activeBlueLed], HIGH);
        blueLedStartTime = millis();
    }
}

void MainGame::updateLedBarTimer() {
    unsigned long elapsed = millis() - simpleGameTimer;
    unsigned long remaining = (elapsed < GAME_DURATION) ? (GAME_DURATION - elapsed) : 0;

    int segment;
    if (remaining == 0) {
        segment = 0;
    } else {
        // This formula ensures that 60s is 10, down to the last moment being 1.
        segment = ((remaining - 1) / (GAME_DURATION / 10)) + 1;
    }

    if (segment > 10) segment = 10;

    // Solid display for most of the game, blinking for the last 10 seconds.
    if (remaining < 10000 && remaining > 0) {
        // Fast blinking to indicate urgency
        bool blinkState = (millis() / 250) % 2;
        ledBar.setLevel(blinkState ? segment : 0);
    } else {
        ledBar.setLevel(segment);
    }
}

void MainGame::displayScore() {
    // This function can be expanded to draw the score on the OLED
    // For now, it's a placeholder
}
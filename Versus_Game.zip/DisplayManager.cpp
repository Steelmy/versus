#include "DisplayManager.h"

bool DisplayManager::whiteMode = false;

void DisplayManager::init(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display) {
    display.begin();
    display.setFont(u8g2_font_5x7_tr);
    display.setContrast(255);
    if (whiteMode) {
        display.sendF("c", 0xa7); // Invert display
    } else {
        display.sendF("c", 0xa6); // Normal display
    }
}

void DisplayManager::showMenu(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display) {
    display.firstPage();
    do {
        display.setFont(u8g2_font_5x7_tr);
        display.drawStr(10, 20, "SPEED GAME");
        display.drawStr(10, 50, "BTN 1: START");
        display.drawStr(10, 70, "BTN 2: RESET");
        display.drawStr(10, 100, "Niveau: LED Bar");
        display.drawStr(10, 120, "Whitemode:");
        if (whiteMode) {
            display.drawStr(80, 120, "(ON)");
        } else {
            display.drawStr(80, 120, "(OFF)");
        }
    } while (display.nextPage());
}

void DisplayManager::toggleWhiteMode(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display) {
    whiteMode = !whiteMode;
    if (whiteMode) {
        display.sendF("c", 0xa7); // Invert display
    } else {
        display.sendF("c", 0xa6); // Normal display
    }
}


void DisplayManager::showDifficultySelect(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display, int difficulty) {
    display.firstPage();
    do {
        display.setFont(u8g2_font_5x7_tr);
        display.drawStr(0, 10, "NIVEAU");
        display.setFont(u8g2_font_ncenB14_tr);
        char diffStr[2];
        sprintf(diffStr, "%d", difficulty);
        display.drawStr(50, 50, diffStr);
        display.setFont(u8g2_font_5x7_tr);
        display.drawStr(0, 120, "BTN 1: Valider");
    } while (display.nextPage());
}

void DisplayManager::showCountdown(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display, int countdownValue) {
    display.firstPage();
    do {
        display.setFont(u8g2_font_ncenB24_tr);
        char countStr[2];
        sprintf(countStr, "%d", countdownValue);
        display.drawStr(55, 64, countStr);
    } while (display.nextPage());
}

void DisplayManager::showGameScore(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display, int redScore, int blueScore, unsigned long remainingTime) {
    display.firstPage();
    do {
        display.setFont(u8g2_font_5x7_tr);
        
        // Score Rouge
        display.drawStr(0, 10, "ROUGE");
        display.setFont(u8g2_font_ncenB14_tr);
        char redStr[4];
        sprintf(redStr, "%d", redScore);
        display.drawStr(20, 40, redStr);
        
        // Score Bleu
        display.setFont(u8g2_font_5x7_tr);
        display.drawStr(0, 60, "BLEU");
        display.setFont(u8g2_font_ncenB14_tr);
        char blueStr[4];
        sprintf(blueStr, "%d", blueScore);
        display.drawStr(20, 90, blueStr);
        
        // Temps restant (déjà calculé avec les pauses)
        display.setFont(u8g2_font_5x7_tr);
        unsigned long remainingSeconds = remainingTime / 1000;
        char timeStr[15];
        sprintf(timeStr, "Temps: %ds", remainingSeconds);
        display.drawStr(70, 120, timeStr);
    } while (display.nextPage());
}

void DisplayManager::showGameOver(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display, int redScore, int blueScore) {
    display.firstPage();
    do {
        display.setFont(u8g2_font_5x7_tr);
        display.drawStr(30, 20, "FIN DE JEU");
        
        // Gagnant
        display.setFont(u8g2_font_7x14B_tr);
        if (redScore > blueScore) {
            display.drawStr(20, 50, "ROUGE GAGNE!");
        } else if (blueScore > redScore) {
            display.drawStr(20, 50, "BLEU GAGNE!");
        } else {
            display.drawStr(40, 50, "EGALITE!");
        }
        
        // Scores
        display.setFont(u8g2_font_5x7_tr);
        char scoreStr[20];
        sprintf(scoreStr, "R:%d  B:%d", redScore, blueScore);
        display.drawStr(40, 80, scoreStr);
        
        display.drawStr(20, 110, "BTN 1: Rejouer");
    } while (display.nextPage());
}

void DisplayManager::showMessage(U8G2_SH1107_SEEED_128X128_1_HW_I2C &display, const char* line1, const char* line2) {
    display.firstPage();
    do {
        display.setFont(u8g2_font_5x7_tr);
        display.drawStr(0, 15, line1);
        if (strlen(line2) > 0) {
            display.drawStr(0, 30, line2);
        }
    } while (display.nextPage());
}

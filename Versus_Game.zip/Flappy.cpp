#include "Flappy.h"
#include "config.h"

// External functions and variables from Jeux.ino
extern void playSuccessSound();
extern void playErrorSound();
extern const int POT_PIN;

Flappy::Flappy() {
    // Constructor
}

void Flappy::setup() {
    x = 20;
    y = 64;
    score = 0;
    pipeX = 128;
    pipeGapY = 64;
    lastUpdate = millis();
    startTime = millis();
    gameOver = false;
}

void Flappy::loop() {
    if (!gameOver) {
        update();
    }
    draw();
}

bool Flappy::isGameOver() {
    return gameOver;
}

int Flappy::getScore() {
    return score;
}

void Flappy::setBestScore(int newBest) {
    bestScore = newBest;
}

int Flappy::getBestScore() {
    return bestScore;
}


void Flappy::update() {
    unsigned long now = millis();
    if (now - lastUpdate < UPDATE_INTERVAL) {
        return;
    }
    lastUpdate = now;

    int potValue = analogRead(POT_PIN);
    y = map(potValue, 0, 1023, 5, 123);

    unsigned long elapsedMs = now - startTime;
    unsigned long elapsedMinutes = elapsedMs / 60000UL;
    int baseSpeed = 6;
    int speedIncreasePerMinute = 2;
    int currentSpeed = baseSpeed + speedIncreasePerMinute * elapsedMinutes;

    pipeX -= currentSpeed;

    if (pipeX + PIPE_WIDTH < 0) {
        pipeX = 128;
        pipeGapY = random(20, 108);
        score++;
        playSuccessSound();
    }

    int gapHalf = GAP_HEIGHT / 2;
    bool inPipeX = (x >= pipeX) && (x <= pipeX + PIPE_WIDTH);
    bool outsideGapY = (y < (pipeGapY - gapHalf)) || (y > (pipeGapY + gapHalf));

    if (inPipeX && outsideGapY) {
        playErrorSound();
        if (score > bestScore) {
            bestScore = score;
        }
        gameOver = true;
    }
}

void Flappy::draw() {
    u8g2.firstPage();
    do {
        u8g2.drawBox(x - 3, y - 3, 7, 7);
        int gapHalf = GAP_HEIGHT / 2;
        int upperHeight = pipeGapY - gapHalf;
        if (upperHeight > 0) {
            u8g2.drawBox(pipeX, 0, PIPE_WIDTH, upperHeight);
        }
        int lowerY = pipeGapY + gapHalf;
        if (lowerY < 128) {
            u8g2.drawBox(pipeX, lowerY, PIPE_WIDTH, 128 - lowerY);
        }
        u8g2.setFont(u8g2_font_6x10_tr);
        char scoreStr[10];
        sprintf(scoreStr, "%d", score);
        u8g2.drawStr(2, 10, scoreStr);
    } while (u8g2.nextPage());
}
